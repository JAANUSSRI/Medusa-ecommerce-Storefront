import { Button } from "@medusajs/ui";
import { Cart, PaymentSession } from "@medusajs/medusa";
import Spinner from "@modules/common/icons/spinner";
import React, { useCallback, useState } from "react";
import useRazorpay, { RazorpayOptions } from "react-razorpay";
import { placeOrder } from "@modules/checkout/actions";

const RazorpayPaymentButton = ({
  session,
  cart,
  notReady,
  "data-testid": dataTestId,
}: {
  session: PaymentSession;
  cart: Omit<Cart, "refundable_amount" | "refunded_total">;
  notReady: boolean;
  "data-testid"?: string;
}) => {
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | undefined>(undefined);
  const [Razorpay] = useRazorpay();

  const orderData = session.data as Record<string, string>;

  const onPaymentCompleted = async () => {
    await placeOrder().catch(() => {
      setErrorMessage("An error occurred, please try again.");
      setSubmitting(false);
    });
  };

  const handlePayment = useCallback(() => {
    if (!Razorpay) {
      console.error("Razorpay SDK not loaded.");
      return;
    }

    const options: RazorpayOptions = {
      key: process.env.NEXT_PUBLIC_RAZORPAY_KEY ?? '',
      amount: session.amount.toString(), // Amount in paise
      order_id: orderData.id,
      currency: cart.region.currency_code.toUpperCase(),
      name: process.env.COMPANY_NAME ?? "Your Company",
      description: `Order number ${orderData.id}`,
      image: "https://example.com/your_logo",
      handler: async (response) => {
        try {
          // Verify the payment signature with your backend
          const verifyResponse = await fetch('/api/payments/verify-payment', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              paymentId: response.razorpay_payment_id,
              orderId: response.razorpay_order_id,
              signature: response.razorpay_signature,
            }),
          });
          const result = await verifyResponse.json();
          if (result.success) {
            onPaymentCompleted();
          } else {
            setErrorMessage('Payment verification failed');
          }
        } catch (error) {
          setErrorMessage('Payment verification error');
        }
      },
      prefill: {
        name: `${cart.billing_address.first_name} ${cart.billing_address.last_name}`,
        email: cart.email,
        contact: cart.shipping_address?.phone ?? '',
      },
      theme: {
        color: '#3399cc',
      },
    };

    const razorpay = new Razorpay(options);
    razorpay.open();
    razorpay.on('payment.failed', (response: { error: { description: any; }; }) => {
      setErrorMessage(`Payment failed: ${response.error.description}`);
    });
  }, [session.amount, orderData.id, cart.region.currency_code, cart.billing_address, cart.email, cart.shipping_address?.phone, Razorpay]);

  return (
    <>
      <Button disabled={submitting || notReady} onClick={handlePayment}>
        {submitting ? <Spinner /> : "Checkout"}
      </Button>
      {errorMessage && (
        <div className="mt-2 text-red-500 text-small-regular">
          {errorMessage}
        </div>
      )}
    </>
  );
};

export default RazorpayPaymentButton;
