// types/razorpay.d.ts

interface Window {
    Razorpay: any; // Define the type as 'any' or create a more specific type if you know the structure
}